import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface PlantResult {
  name: string;
  sci: string;
  score: number;
  foto: string;
  family?: string;
  light?: string;
  water?: string;
  temp?: string;
  summary?: string;
  nomeNordeste?: string;
  nomeSudeste?: string;
  nameEnglish?: string;
  nameMexico?: string;
  issues?: { label: string; desc: string; severity: string }[];
  actions?: { icon: string; label: string; desc: string }[];
  tip?: string;
  confidence?: number;
  aiNote?: string;
}

export interface DiaryEntry {
  date: string;
  score: number;
  note: string;
  foto: string;
}

export interface UserPlant {
  id: string;
  name: string;
  sci: string;
  foto: string;
  score: number;
  needsWater: boolean;
  diary: DiaryEntry[];
  addedAt: string;
}

interface AppStore {
  currentResult: PlantResult | null;
  setResult: (r: PlantResult) => void;
  plants: UserPlant[];
  addPlant: (p: UserPlant) => void;
  removePlant: (id: string) => void;
  addDiaryEntry: (plantId: string, entry: DiaryEntry) => void;
  markWatered: (plantId: string) => void;
  scanCount: number;
  incScan: () => void;
  isOffline: boolean;
  setOffline: (v: boolean) => void;
}

export const useStore = create<AppStore>()(
  persist(
    (set) => ({
      currentResult: null,
      setResult: (r) => set({ currentResult: r }),
      plants: [
        { id: 'monstera', name: 'Monstera', sci: 'Monstera deliciosa', foto: 'https://images.unsplash.com/photo-1614594975525-e45190c55d0b?w=400&q=80', score: 85, needsWater: true, diary: [{ date: '10/03', score: 78, note: 'Folhas novas brotando', foto: 'https://images.unsplash.com/photo-1614594975525-e45190c55d0b?w=200&q=70' }, { date: '14/03', score: 85, note: 'Muito saudável!', foto: 'https://images.unsplash.com/photo-1614594975525-e45190c55d0b?w=200&q=70' }], addedAt: '10/03/2025' },
        { id: 'echeveria', name: 'Suculenta', sci: 'Echeveria elegans', foto: 'https://images.unsplash.com/photo-1459411621453-7b03977f4bfc?w=400&q=80', score: 92, needsWater: false, diary: [{ date: '14/03', score: 92, note: 'Crescendo bem', foto: 'https://images.unsplash.com/photo-1459411621453-7b03977f4bfc?w=200&q=70' }], addedAt: '11/03/2025' },
        { id: 'samambaia', name: 'Samambaia', sci: 'Nephrolepis exaltata', foto: 'https://images.unsplash.com/photo-1597305877032-0668b3c6413a?w=400&q=80', score: 58, needsWater: true, diary: [{ date: '09/03', score: 70, note: 'Folhas amarelando', foto: 'https://images.unsplash.com/photo-1597305877032-0668b3c6413a?w=200&q=70' }, { date: '14/03', score: 58, note: '⚠ Atenção necessária', foto: 'https://images.unsplash.com/photo-1597305877032-0668b3c6413a?w=200&q=70' }], addedAt: '09/03/2025' },
      ],
      addPlant: (p) => set((s) => ({ plants: [p, ...s.plants] })),
      removePlant: (id) => set((s) => ({ plants: s.plants.filter(p => p.id !== id) })),
      addDiaryEntry: (plantId, entry) => set((s) => ({
        plants: s.plants.map(p => p.id === plantId ? { ...p, diary: [...p.diary, entry] } : p)
      })),
      markWatered: (plantId) => set((s) => ({
        plants: s.plants.map(p => p.id === plantId ? { ...p, needsWater: false } : p)
      })),
      scanCount: 12,
      incScan: () => set((s) => ({ scanCount: s.scanCount + 1 })),
      isOffline: false,
      setOffline: (v) => set({ isOffline: v }),
    }),
    { name: 'planta-scan-storage' }
  )
);
