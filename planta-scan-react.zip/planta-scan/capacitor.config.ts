import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.luminadesigner.plantascan',
  appName: 'Planta&Scan',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000,
      backgroundColor: '#22c47f',
      showSpinner: false,
    },
    StatusBar: {
      style: 'light',
      backgroundColor: '#22c47f',
    },
    Camera: {
      quality: 90,
    }
  }
};

export default config;
