// ResultPage
import { ArrowLeft, BookOpen } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../store';
import HealthGauge from '../components/HealthGauge';
import BottomNav from '../components/BottomNav';
import { toast } from 'sonner';

export function ResultPage() {
  const nav = useNavigate();
  const { currentResult, addPlant, plants } = useStore();

  if (!currentResult) return (
    <div className="flex flex-col h-full items-center justify-center gap-4 px-6">
      <p className="font-display text-brown text-center text-lg">Nenhum resultado encontrado.</p>
      <button onClick={() => nav('/scan')} className="bg-green-light text-white px-6 py-3 rounded-xl font-semibold">Escanear Planta</button>
    </div>
  );

  const r = currentResult;
  const scoreColor = r.score >= 75 ? '#22c47f' : r.score >= 50 ? '#e0780d' : '#d63b3b';

  const handleSave = () => {
    const exists = plants.find(p => p.sci === r.sci);
    if (exists) { toast.info('Esta planta já está no seu jardim!'); return; }
    addPlant({ id: Date.now().toString(), name: r.name, sci: r.sci, foto: r.foto, score: r.score, needsWater: r.score < 80, diary: [{ date: new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }), score: r.score, note: 'Adicionada ao jardim', foto: r.foto }], addedAt: new Date().toLocaleDateString('pt-BR') });
    toast.success('🌿 Planta salva no seu jardim!');
    nav('/garden');
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto scrollbar-none pb-4">
        {/* Hero image */}
        <div className="relative h-56 flex-shrink-0">
          <img src={r.foto} alt={r.name} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-cream to-transparent" />
          <button onClick={() => nav(-1)} className="absolute top-4 left-4 w-10 h-10 bg-white/85 rounded-full flex items-center justify-center">
            <ArrowLeft className="w-5 h-5 text-brown" />
          </button>
          {r.confidence && <div className="absolute top-4 right-4 bg-white/88 rounded-xl px-3 py-1 text-xs font-bold" style={{ color: scoreColor }}>🤖 {r.confidence}% confiança</div>}
        </div>

        <div className="px-4 -mt-12 relative z-10 space-y-3">
          {/* Main card */}
          <div className="animate-pop bg-white rounded-2xl p-4 shadow-lg border border-cream-dark">
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1">
                {r.family && <p className="text-[11px] font-bold text-green uppercase tracking-widest mb-1">{r.family}</p>}
                <h1 className="font-display text-2xl font-bold text-brown">{r.name}</h1>
                <p className="text-xs text-muted italic mb-2">{r.sci}</p>
                {r.aiNote && <span className="text-[11px] bg-green-bg text-green-dark px-2.5 py-1 rounded-full font-semibold">{r.aiNote}</span>}
              </div>
              <HealthGauge score={r.score} />
            </div>
            {r.summary && <p className="text-xs text-muted leading-relaxed mt-3 pt-3 border-t border-cream-dark">{r.summary}</p>}
            {(r.light || r.water) && (
              <div className="flex flex-wrap gap-2 mt-3">
                {r.light && <span className="text-xs bg-green-bg text-green-dark px-2.5 py-1 rounded-full font-medium">☀ {r.light}</span>}
                {r.water && <span className="text-xs bg-green-bg text-green-dark px-2.5 py-1 rounded-full font-medium">💧 {r.water}</span>}
                {r.temp  && <span className="text-xs bg-green-bg text-green-dark px-2.5 py-1 rounded-full font-medium">🌡 {r.temp}</span>}
              </div>
            )}
          </div>

          {/* Issues */}
          {r.issues && r.issues.length > 0 && (
            <div>
              <h2 className="font-display font-semibold text-brown mb-2">⚠ Problemas Detectados</h2>
              {r.issues.map((issue, i) => (
                <div key={i} className={`rounded-2xl p-3 mb-2 border flex gap-3 ${issue.severity === 'alert' ? 'bg-red-50 border-red-200' : 'bg-amber-50 border-amber-200'}`}>
                  <span className="text-xl">{issue.severity === 'alert' ? '🚨' : '⚠️'}</span>
                  <div><p className="font-semibold text-sm text-brown">{issue.label}</p><p className="text-xs text-muted mt-0.5">{issue.desc}</p></div>
                </div>
              ))}
            </div>
          )}
          {(!r.issues || r.issues.length === 0) && (
            <div className="bg-green-bg rounded-2xl p-3 flex items-center gap-3">
              <span className="text-2xl">✅</span>
              <p className="text-sm text-green-dark font-medium">Nenhum problema detectado. Planta saudável!</p>
            </div>
          )}

          {/* Regional names */}
          {(r.nomeNordeste || r.nomeSudeste || r.nameEnglish) && (
            <div className="bg-white rounded-2xl p-4 border border-cream-dark shadow-sm">
              <div className="flex items-center gap-2 mb-3">
                <span className="text-lg">🌍</span>
                <p className="font-display font-bold text-brown text-sm">Nomes por região</p>
              </div>
              {[
                { label: 'Nordeste BR', value: r.nomeNordeste, bg: 'bg-green-bg', color: 'text-green-dark' },
                { label: 'Sudeste BR',  value: r.nomeSudeste,  bg: 'bg-green-bg', color: 'text-green-dark' },
                { label: '🇺🇸 English', value: r.nameEnglish, bg: 'bg-blue-50',   color: 'text-blue-700' },
                { label: '🇲🇽 México',  value: r.nameMexico,  bg: 'bg-amber-50',  color: 'text-amber-700' },
              ].filter(x => x.value).map(x => (
                <div key={x.label} className="flex items-center gap-2 py-2 border-t border-cream-dark first:border-t-0">
                  <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-md ${x.bg} ${x.color}`}>{x.label}</span>
                  <span className="text-sm text-brown">{x.value}</span>
                </div>
              ))}
            </div>
          )}

          {/* AI tip */}
          {r.tip && (
            <div className="rounded-2xl p-4 flex gap-3" style={{ background: 'linear-gradient(135deg,#0d3b22,#1a7a50)' }}>
              <span className="text-2xl flex-shrink-0">💡</span>
              <div><p className="font-display font-bold text-white text-sm mb-1">Dica da IA</p><p className="text-xs text-white/75 leading-relaxed">{r.tip}</p></div>
            </div>
          )}

          <button onClick={handleSave} className="w-full bg-green-light text-white rounded-2xl py-4 font-display font-bold text-base shadow-xl shadow-green-light/35">Salvar no Meu Jardim</button>
          <button onClick={() => nav('/scan')} className="w-full bg-white text-green border border-green-light/50 rounded-2xl py-3 font-semibold text-sm">📷 Escanear outra planta</button>
        </div>
      </div>
      <BottomNav />
    </div>
  );
}
