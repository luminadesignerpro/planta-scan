import { useState, useRef } from 'react';
import { ArrowLeft, Image, Zap } from 'lucide-react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useAI, ScanMode } from '../hooks/useAI';
import { useStore } from '../store';
import { toast } from 'sonner';

export default function ScanPage() {
  const nav = useNavigate();
  const [params] = useSearchParams();
  const [mode, setMode] = useState<ScanMode>((params.get('mode') as ScanMode) || 'identify');
  const [preview, setPreview] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const { analyze, loading, progress, statusText } = useAI();
  const { setResult, incScan, isOffline } = useStore();

  const handleFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = e => setPreview(e.target?.result as string);
    reader.readAsDataURL(file);
  };

  const handleAnalyze = async () => {
    const img = preview || 'demo';
    const result = await analyze(img, mode, isOffline);
    if (result) {
      setResult(result);
      incScan();
      nav('/result');
      toast.success(`✅ ${mode === 'identify' ? 'Identificada' : 'Diagnóstico pronto'}: ${result.name}!`);
    } else {
      toast.error('Erro na análise. Tente novamente.');
    }
  };

  return (
    <div className="flex flex-col h-full" style={{ background: '#060e08' }}>
      {/* Header */}
      <div className="flex items-center justify-between px-4 pt-4 pb-3 flex-shrink-0">
        <div className="flex items-center gap-3">
          <button onClick={() => nav(-1)}
            className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center">
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <span className="font-display font-semibold text-white text-lg">
            {mode === 'identify' ? 'Identificar Planta' : 'Diagnosticar Doença'}
          </span>
        </div>
        <div className="flex gap-2">
          <button onClick={() => setMode('identify')}
            className="px-3 py-1.5 rounded-full text-[11px] font-semibold transition-colors"
            style={{ background: mode === 'identify' ? '#22c47f' : 'rgba(255,255,255,.1)', color: mode === 'identify' ? 'white' : 'rgba(255,255,255,.5)' }}>
            Identificar
          </button>
          <button onClick={() => setMode('diagnose')}
            className="px-3 py-1.5 rounded-full text-[11px] font-semibold transition-colors"
            style={{ background: mode === 'diagnose' ? '#d63b3b' : 'rgba(255,255,255,.1)', color: mode === 'diagnose' ? 'white' : 'rgba(255,255,255,.5)' }}>
            Diagnosticar
          </button>
        </div>
      </div>

      {/* Camera area */}
      <div className="flex-1 mx-4 mb-2 rounded-3xl overflow-hidden relative flex items-center justify-center"
        style={{ background: '#0d1e10' }}>
        {preview ? (
          <img src={preview} className="w-full h-full object-cover" alt="preview" />
        ) : (
          <div className="flex flex-col items-center gap-3 text-center px-6">
            <div className="w-16 h-16 rounded-full flex items-center justify-center animate-pulse-slow"
              style={{ background: 'rgba(34,196,127,.12)' }}>
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="rgba(34,196,127,.7)" strokeWidth="1.5">
                <path d="M23 19a2 2 0 01-2 2H3a2 2 0 01-2-2V8a2 2 0 012-2h4l2-3h6l2 3h4a2 2 0 012 2z"/>
                <circle cx="12" cy="13" r="4"/>
              </svg>
            </div>
            <p className="text-white/30 text-sm">Aponte para uma planta<br /><span className="text-xs">ou envie da galeria</span></p>
          </div>
        )}

        {/* Corners */}
        <div className="absolute inset-5 pointer-events-none">
          {[['top-0 left-0','border-t-2 border-l-2 rounded-tl-lg'],['top-0 right-0','border-t-2 border-r-2 rounded-tr-lg'],
            ['bottom-0 left-0','border-b-2 border-l-2 rounded-bl-lg'],['bottom-0 right-0','border-b-2 border-r-2 rounded-br-lg']
          ].map(([pos, cls]) => (
            <div key={pos} className={`absolute w-7 h-7 ${pos} ${cls}`} style={{ borderColor: 'rgba(34,196,127,.7)' }} />
          ))}
          {!loading && <div className="absolute left-0 right-0 h-[3px] animate-scan" style={{ background: 'linear-gradient(to right,transparent,rgba(34,196,127,.9),transparent)', boxShadow: '0 0 12px rgba(34,196,127,.6)' }} />}
        </div>

        {/* Loading overlay */}
        {loading && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 rounded-3xl"
            style={{ background: 'rgba(6,14,8,.8)' }}>
            <div className="w-16 h-16 rounded-full border-3 border-green-light/30 border-t-green-light animate-spin" />
            <div className="bg-white/96 rounded-2xl px-6 py-4 text-center max-w-[240px]">
              <p className="font-display font-semibold text-brown text-sm mb-1">{statusText}</p>
              <p className="text-xs text-muted mb-2">Claude está analisando</p>
              <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                <div className="h-full bg-green-light rounded-full transition-all duration-400"
                  style={{ width: `${progress}%` }} />
              </div>
            </div>
          </div>
        )}
      </div>

      <p className="text-center text-white/20 text-[11px] py-1">
        {mode === 'identify' ? 'Centralize a planta no quadro' : 'Mostre as folhas com problemas'}
      </p>

      {/* Actions */}
      <div className="flex items-center justify-around px-4 pb-6 pt-2 flex-shrink-0">
        <button onClick={() => fileRef.current?.click()}
          className="flex flex-col items-center gap-1.5 px-5 py-3 rounded-2xl"
          style={{ background: 'rgba(255,255,255,.07)', color: 'rgba(255,255,255,.5)' }}>
          <Image className="w-6 h-6" />
          <span className="text-[11px]">Galeria</span>
        </button>
        <button onClick={handleAnalyze} disabled={loading}
          className="w-[70px] h-[70px] rounded-full flex items-center justify-center active:scale-95 transition-transform disabled:opacity-60"
          style={{ background: '#22c47f', border: '5px solid rgba(255,255,255,.15)', boxShadow: '0 0 0 8px rgba(34,196,127,.18)' }}>
          <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2">
            <circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="5"/>
          </svg>
        </button>
        <button onClick={() => toast.info('💡 Dica: mantenha a planta bem iluminada e centralizada.')}
          className="flex flex-col items-center gap-1.5 px-5 py-3 rounded-2xl"
          style={{ background: 'rgba(255,255,255,.07)', color: 'rgba(255,255,255,.5)' }}>
          <Zap className="w-6 h-6" />
          <span className="text-[11px]">IA Dicas</span>
        </button>
      </div>

      <input ref={fileRef} type="file" accept="image/*" className="hidden"
        onChange={e => e.target.files?.[0] && handleFile(e.target.files[0])} />
    </div>
  );
}
