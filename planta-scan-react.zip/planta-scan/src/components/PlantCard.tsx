import { Droplets, Sun } from 'lucide-react';

interface Props {
  name: string;
  sci: string;
  foto: string;
  score: number;
  needsWater?: boolean;
  needsSun?: boolean;
  onClick?: () => void;
}

export default function PlantCard({ name, sci, foto, score, needsWater, needsSun, onClick }: Props) {
  const scoreColor = score >= 75 ? 'text-green' : score >= 50 ? 'text-warn' : 'text-red-500';
  const borderColor = score >= 75 ? 'border-green-light/30' : score >= 50 ? 'border-warn/30' : 'border-red-400/30';

  return (
    <button onClick={onClick}
      className={`bg-white rounded-xl overflow-hidden border ${borderColor} shadow-sm text-left w-full active:scale-95 transition-transform`}
    >
      <div className="relative h-28 overflow-hidden">
        <img src={foto} alt={name} className="w-full h-full object-cover" />
        <div className={`absolute top-2 right-2 bg-white/90 rounded-lg px-2 py-0.5 text-xs font-bold ${scoreColor}`}>
          {score}●
        </div>
      </div>
      <div className="p-2.5">
        <p className="font-display font-bold text-sm text-brown truncate">{name}</p>
        <p className="text-[10px] text-muted italic truncate">{sci}</p>
        {(needsWater || needsSun) && (
          <div className="flex gap-2 mt-1.5">
            {needsWater && (
              <span className="flex items-center gap-0.5 text-[10px] text-warn font-semibold">
                <Droplets className="w-2.5 h-2.5" /> Regar
              </span>
            )}
            {needsSun && (
              <span className="flex items-center gap-0.5 text-[10px] text-warn font-semibold">
                <Sun className="w-2.5 h-2.5" /> Sol
              </span>
            )}
          </div>
        )}
      </div>
    </button>
  );
}
