import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'sonner';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import HomePage from './pages/HomePage';
import ScanPage from './pages/ScanPage';
import { ResultPage } from './pages/ResultPage';
import { GardenPage, DiaryPage, CatalogPage, CatalogDetailPage, ProfilePage } from './pages/OtherPages';
import LoginPage from './pages/LoginPage';

const qc = new QueryClient();

export default function App() {
  return (
    <QueryClientProvider client={qc}>
      <BrowserRouter>
        <div className="h-[100dvh] w-full max-w-[430px] mx-auto overflow-hidden bg-cream relative">
          <Routes>
            <Route path="/"             element={<HomePage />} />
            <Route path="/scan"         element={<ScanPage />} />
            <Route path="/result"       element={<ResultPage />} />
            <Route path="/garden"       element={<GardenPage />} />
            <Route path="/diary/:id"    element={<DiaryPage />} />
            <Route path="/catalog"      element={<CatalogPage />} />
            <Route path="/catalog/:id"  element={<CatalogDetailPage />} />
            <Route path="/profile"      element={<ProfilePage />} />
            <Route path="/login"        element={<LoginPage />} />
            <Route path="*"             element={<Navigate to="/" />} />
          </Routes>
        </div>
        <Toaster position="bottom-center" richColors />
      </BrowserRouter>
    </QueryClientProvider>
  );
}
