import { useNavigate } from 'react-router-dom';
import { Leaf } from 'lucide-react';

export default function LoginPage() {
  const nav = useNavigate();

  return (
    <div className="flex flex-col h-full bg-white">
      <div className="relative h-56 overflow-hidden flex-shrink-0">
        <img src="https://images.unsplash.com/photo-1545241047-6083a3684587?w=600&q=75"
          className="absolute inset-0 w-full h-full object-cover" alt="plantas" />
        <div className="absolute inset-0" style={{ background: 'linear-gradient(170deg,rgba(8,30,16,.5),rgba(10,50,28,.88))' }} />
        <div className="relative z-10 h-full flex flex-col items-center justify-center gap-3">
          <div className="w-14 h-14 bg-white/15 rounded-2xl flex items-center justify-center border border-white/20">
            <Leaf className="w-8 h-8 text-white" />
          </div>
          <h1 className="font-display text-3xl font-bold text-white">
            Planta<span style={{ color: '#7de8b8' }}>&</span>Scan
          </h1>
          <p className="text-sm text-white/65 text-center">Identifique, cuide e compartilhe suas plantas</p>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-7">
        <h2 className="font-display text-2xl font-bold text-brown mb-1">Bem-vindo de volta!</h2>
        <p className="text-sm text-muted mb-6">Entre para cuidar das suas plantas</p>

        <div className="space-y-3 mb-5">
          <div>
            <label className="block text-xs font-semibold text-brown/70 mb-1.5">E-mail</label>
            <input type="email" placeholder="seu@email.com"
              className="w-full px-4 py-3 border border-cream-dark rounded-2xl text-sm text-brown bg-cream outline-none" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-brown/70 mb-1.5">Senha</label>
            <input type="password" placeholder="••••••••"
              className="w-full px-4 py-3 border border-cream-dark rounded-2xl text-sm text-brown bg-cream outline-none" />
          </div>
        </div>

        <button onClick={() => nav('/')}
          className="w-full bg-green-light text-white rounded-2xl py-4 font-display font-bold text-base shadow-xl shadow-green-light/35 mb-4">
          Entrar
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="flex-1 h-px bg-cream-dark" />
          <span className="text-xs text-muted">ou continue com</span>
          <div className="flex-1 h-px bg-cream-dark" />
        </div>

        <button onClick={() => nav('/')}
          className="w-full bg-white border border-cream-dark rounded-2xl py-3.5 flex items-center justify-center gap-2.5 font-semibold text-sm text-brown">
          <svg width="18" height="18" viewBox="0 0 24 24">
            <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
            <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
            <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
            <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
          </svg>
          Entrar com Google
        </button>

        <p className="text-center mt-5 text-sm text-muted">
          Não tem conta?{' '}
          <button onClick={() => nav('/')} className="text-green font-semibold">Cadastre-se grátis</button>
        </p>
      </div>
    </div>
  );
}
