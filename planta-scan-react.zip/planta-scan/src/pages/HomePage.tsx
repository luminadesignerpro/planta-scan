import { motion } from 'framer-motion';
import { ScanLine, ArrowRight, AlertTriangle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../store';
import PlantCard from '../components/PlantCard';
import BottomNav from '../components/BottomNav';

const tips = [
  { emoji: '💧', text: 'Regue cedo pela manhã para evitar fungos nas folhas', sub: 'Monsteras e Samambaias adoram manhãs úmidas.' },
  { emoji: '☀️', text: 'Luz indireta é ideal para a maioria das plantas de interior', sub: 'Coloque perto de janelas com cortinas finas.' },
  { emoji: '✂️', text: 'Pode suas plantas no início da primavera', sub: 'Retire folhas amarelas para estimular crescimento.' },
  { emoji: '🌍', text: 'Muitas plantas têm nomes diferentes por região', sub: 'Costela-de-Adão no Sul, Bananeirinha no Nordeste!' },
];

export default function HomePage() {
  const nav = useNavigate();
  const plants = useStore(s => s.plants);
  const [tipIdx, setTipIdx] = React.useState(0);
  const tip = tips[tipIdx];

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto scrollbar-none pb-4">
        {/* Hero */}
        <div className="relative h-56 overflow-hidden flex-shrink-0">
          <img src="https://images.unsplash.com/photo-1545241047-6083a3684587?w=900&q=85"
            className="w-full h-full object-cover" alt="plantas" />
          <div className="absolute inset-0 bg-gradient-to-t from-cream via-cream/20 to-transparent" />
          <div className="absolute top-4 left-5 flex items-center gap-2">
            <div className="w-8 h-8 bg-green-light rounded-xl flex items-center justify-center shadow-lg shadow-green-light/40">
              <span className="text-white text-base">🌿</span>
            </div>
            <span className="font-display font-semibold text-brown">Planta<span className="text-green">&</span>Scan</span>
          </div>
          <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }}
            className="absolute bottom-0 left-0 right-0 px-5 pb-4">
            <h1 className="font-display text-3xl font-bold text-brown leading-tight">
              Identifique suas<br /><em className="text-green not-italic">plantas</em> com IA
            </h1>
            <p className="text-sm text-muted mt-1">Foto → espécie, saúde e cuidados em segundos.</p>
          </motion.div>
        </div>

        <div className="px-4 space-y-3 mt-3">
          {/* Scan CTA */}
          <motion.button initial={{ y: 16, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: .08 }}
            onClick={() => nav('/scan')}
            className="w-full bg-green-light rounded-2xl p-4 flex items-center justify-between shadow-xl shadow-green-light/40 active:scale-98 transition-transform">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 bg-white/20 rounded-xl flex items-center justify-center">
                <ScanLine className="w-6 h-6 text-white" />
              </div>
              <div className="text-left">
                <span className="block font-display text-lg font-bold text-white">Escanear Planta</span>
                <span className="block text-xs text-white/80">IA identifica em segundos • grátis</span>
              </div>
            </div>
            <div className="w-9 h-9 bg-white/20 rounded-full flex items-center justify-center">
              <ArrowRight className="w-5 h-5 text-white" />
            </div>
          </motion.button>

          {/* Diagnose CTA */}
          <motion.button initial={{ y: 16, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: .14 }}
            onClick={() => nav('/scan?mode=diagnose')}
            className="w-full bg-white border border-red-400/25 rounded-2xl p-3.5 flex items-center gap-3 active:scale-98 transition-transform">
            <div className="w-10 h-10 bg-red-50 rounded-xl flex items-center justify-center flex-shrink-0">
              <AlertTriangle className="w-5 h-5 text-red-500" />
            </div>
            <div className="text-left flex-1">
              <span className="block font-display font-semibold text-brown text-sm">Diagnosticar Doença</span>
              <span className="text-xs text-muted">Foto → problemas detectados pela IA</span>
            </div>
            <ArrowRight className="w-4 h-4 text-muted" />
          </motion.button>

          {/* Tip card */}
          <motion.div initial={{ y: 16, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: .2 }}
            onClick={() => setTipIdx(i => (i + 1) % tips.length)}
            className="rounded-2xl p-4 cursor-pointer overflow-hidden"
            style={{ background: 'linear-gradient(135deg,#1a5c3a,#0d9e6a)' }}>
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-lg">{tip.emoji}</span>
                  <span className="text-[11px] font-semibold text-white/55 uppercase tracking-widest">Dica do Dia</span>
                </div>
                <p className="font-display font-semibold text-white text-sm leading-tight max-w-[200px]">{tip.text}</p>
                <p className="text-[11px] text-white/55 mt-1">Toque para próxima dica</p>
              </div>
              <div className="w-11 h-11 bg-white/12 rounded-full flex items-center justify-center text-2xl flex-shrink-0">
                {tip.emoji}
              </div>
            </div>
            <div className="flex gap-1.5 mt-3">
              {tips.map((_, i) => (
                <div key={i} className="h-1 rounded-full transition-all duration-300"
                  style={{ width: i === tipIdx ? 20 : 6, background: i === tipIdx ? 'rgba(255,255,255,.7)' : 'rgba(255,255,255,.3)' }} />
              ))}
            </div>
          </motion.div>

          {/* Recent plants */}
          <motion.div initial={{ y: 16, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: .26 }}>
            <div className="flex items-center justify-between mb-3">
              <h2 className="font-display text-lg font-semibold text-brown">Plantas Recentes</h2>
              <button onClick={() => nav('/garden')} className="text-sm text-green font-semibold">Ver todas →</button>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {plants.slice(0, 3).map((p, i) => (
                <div key={p.id} className={i === 2 ? 'col-span-2' : ''}>
                  {i === 2 ? (
                    <button onClick={() => { useStore.getState().setResult({ name: p.name, sci: p.sci, score: p.score, foto: p.foto }); nav('/result'); }}
                      className="w-full bg-white rounded-xl overflow-hidden border border-cream-dark shadow-sm flex active:scale-98 transition-transform">
                      <div className="w-24 flex-shrink-0 overflow-hidden">
                        <img src={p.foto} className="w-full h-full object-cover" alt={p.name} />
                      </div>
                      <div className="p-3 flex-1">
                        <p className="font-display font-bold text-sm text-brown">{p.name}</p>
                        <p className="text-[10px] text-muted italic mb-2">{p.sci}</p>
                        {p.needsWater && <span className="text-[10px] text-warn font-semibold">💧 Regar</span>}
                      </div>
                    </button>
                  ) : (
                    <PlantCard {...p} needsWater={p.needsWater}
                      onClick={() => { useStore.getState().setResult({ name: p.name, sci: p.sci, score: p.score, foto: p.foto }); nav('/result'); }} />
                  )}
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
      <BottomNav />
    </div>
  );
}

import React from 'react';
