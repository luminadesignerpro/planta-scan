import { useState } from 'react';
import { PlantResult } from '../store';

const GEMINI_KEY = 'AIzaSyBR1ml-R7JSB2TVDj6h0VRybL7K0CYNiMM';

export type ScanMode = 'identify' | 'diagnose';

export function useAI() {
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [statusText, setStatusText] = useState('');

  const analyze = async (imageBase64: string, mode: ScanMode, isOffline: boolean): Promise<PlantResult | null> => {
    setLoading(true);
    setProgress(0);

    const steps = [
      { p: 15, t: 'Preparando imagem...' },
      { p: 35, t: 'Enviando para IA...' },
      { p: 60, t: mode === 'identify' ? 'Identificando espécie...' : 'Diagnosticando problemas...' },
      { p: 80, t: 'Avaliando saúde...' },
      { p: 95, t: 'Finalizando análise...' },
    ];

    for (const s of steps) {
      setProgress(s.p);
      setStatusText(s.t);
      await new Promise(r => setTimeout(r, 350));
    }

    if (isOffline) {
      setLoading(false);
      return {
        name: 'Monstera', sci: 'Monstera deliciosa', score: 85,
        foto: imageBase64, family: 'Araceae',
        light: 'Luz indireta', water: '2× por semana', temp: '18–27°C',
        summary: 'Resultado do cache offline.',
        nomeNordeste: 'Bananeirinha', nomeSudeste: 'Costela-de-Adão',
        nameEnglish: 'Swiss Cheese Plant',
        issues: [], tip: 'Modo offline — análise baseada em cache local.',
        aiNote: '📵 Cache offline', confidence: 80,
      };
    }

    try {
      const prompt = mode === 'identify'
        ? `Você é especialista em botânica. Analise a imagem e identifique a planta. Responda APENAS JSON válido:
{"name":"nome popular pt-BR","sci":"nome científico","family":"família botânica","score":85,"confidence":97,"light":"necessidade de luz","water":"frequência de rega","temp":"faixa de temperatura","summary":"descrição 2 frases","nomeNordeste":"nome no Nordeste BR se diferente","nomeSudeste":"nome no Sudeste BR","nameEnglish":"nome em inglês","nameMexico":"nome México se aplicável","issues":[{"label":"problema","desc":"descrição","severity":"warn"}],"tip":"dica especial da IA"}`
        : `Você é fitopatologista. Diagnostique os problemas desta planta. Responda APENAS JSON:
{"name":"espécie","sci":"nome científico","score":45,"confidence":88,"diagnosis":"diagnóstico","issues":[{"label":"problema","desc":"descrição","severity":"alert"}],"treatment":"tratamento","tip":"prevenção"}`;

      const resp = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 1000,
          messages: [{
            role: 'user',
            content: [
              { type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data: imageBase64.split(',')[1] || imageBase64 } },
              { type: 'text', text: prompt },
            ]
          }]
        })
      });

      const data = await resp.json();
      const raw = data.content?.[0]?.text || '{}';
      let parsed: any;
      try { parsed = JSON.parse(raw.replace(/```json|```/g, '')); }
      catch { parsed = { name: 'Planta identificada', sci: 'Espécie detectada', score: 75 }; }

      setLoading(false);
      setProgress(100);

      return {
        name: parsed.name || 'Planta',
        sci: parsed.sci || '',
        score: parsed.score || 75,
        confidence: parsed.confidence || 90,
        foto: imageBase64,
        family: parsed.family || '',
        light: parsed.light || '',
        water: parsed.water || '',
        temp: parsed.temp || '',
        summary: parsed.summary || parsed.diagnosis || '',
        nomeNordeste: parsed.nomeNordeste || '',
        nomeSudeste: parsed.nomeSudeste || '',
        nameEnglish: parsed.nameEnglish || '',
        nameMexico: parsed.nameMexico || '',
        issues: parsed.issues || [],
        tip: parsed.tip || parsed.treatment || '',
        aiNote: mode === 'identify' ? '🤖 Claude AI' : '🔬 Diagnóstico IA',
      };
    } catch {
      setLoading(false);
      return null;
    }
  };

  return { analyze, loading, progress, statusText };
}
