import { Home, Leaf, ScanLine, Grid2x2, User } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';

const tabs = [
  { path: '/',         icon: Home,      label: 'Início'   },
  { path: '/garden',   icon: Leaf,      label: 'Jardim'   },
  { path: '/scan',     icon: ScanLine,  label: '',        fab: true },
  { path: '/catalog',  icon: Grid2x2,   label: 'Catálogo' },
  { path: '/profile',  icon: User,      label: 'Perfil'   },
];

export default function BottomNav() {
  const nav = useNavigate();
  const { pathname } = useLocation();

  return (
    <nav className="flex-shrink-0 h-[72px] bg-white border-t border-cream-dark flex items-center justify-around relative safe-pb z-50">
      {tabs.map(t => {
        const active = pathname === t.path;
        if (t.fab) return (
          <button key={t.path}
            onClick={() => nav(t.path)}
            className="absolute -top-6 left-1/2 -translate-x-1/2 w-14 h-14 bg-green-light rounded-full flex items-center justify-center shadow-lg shadow-green-light/40 active:scale-95 transition-transform"
          >
            <t.icon className="w-6 h-6 text-white" />
          </button>
        );
        return (
          <button key={t.path} onClick={() => nav(t.path)}
            className={`flex flex-col items-center gap-1 px-4 py-2 transition-colors ${active ? 'text-green' : 'text-gray-400'}`}
          >
            <t.icon className="w-5 h-5" />
            <span className="text-[10px] font-medium">{t.label}</span>
          </button>
        );
      })}
      <div className="w-12" />
    </nav>
  );
}
