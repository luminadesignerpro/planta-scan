# 🌿 Planta&Scan

App de identificação de plantas com IA (Gemini), diário, comunidade e loja.

## 🚀 Como rodar no Antigravity / VS Code

### 1. Instalar dependências
```bash
npm install
```

### 2. Rodar em desenvolvimento
```bash
npm run dev
```
Abra `http://localhost:5173` no navegador.

### 3. Build para produção
```bash
npm run build
```

---

## 📱 Gerar APK Android

### Pré-requisitos
- Node.js 18+
- Android Studio instalado
- Java JDK 17+

### Passos

```bash
# 1. Build do projeto web
npm run build

# 2. Adicionar plataforma Android (só na primeira vez)
npm run cap:add:android

# 3. Sincronizar arquivos
npm run cap:sync

# 4. Abrir no Android Studio
npm run cap:open:android
```

No Android Studio:
- **Build → Generate Signed Bundle / APK**
- Escolha **APK**
- Siga os passos para assinar e gerar o `.apk`

---

## ⚙️ Configuração

### Chave da API Gemini
Em `src/hooks/useAI.ts`, linha 4:
```ts
const GEMINI_KEY = 'SUA_CHAVE_AQUI';
```

### App ID (para publicar na Play Store)
Em `capacitor.config.ts`:
```ts
appId: 'com.seudominio.plantascan',
appName: 'Planta&Scan',
```

---

## 📁 Estrutura do projeto

```
src/
├── pages/
│   ├── HomePage.tsx       # Tela inicial
│   ├── ScanPage.tsx       # Scanner com câmera + IA
│   ├── ResultPage.tsx     # Resultado da identificação
│   ├── OtherPages.tsx     # Jardim, Diário, Catálogo, Perfil
│   └── LoginPage.tsx      # Login
├── components/
│   ├── BottomNav.tsx      # Navegação inferior
│   ├── HealthGauge.tsx    # Gauge de saúde circular
│   └── PlantCard.tsx      # Card de planta
├── hooks/
│   └── useAI.ts           # Integração Gemini API
├── data/
│   └── catalog.ts         # 12 plantas com nomes regionais
├── store.ts               # Estado global (Zustand)
└── App.tsx                # Rotas
```

## 🌍 Funcionalidades

- ✅ **IA Real** — Gemini identifica plantas por foto
- ✅ **Diagnóstico de doenças** — detecta problemas nas folhas
- ✅ **Nomes regionais** — Costela-de-Adão (Sul) / Bananeirinha (Nordeste)
- ✅ **Diário da planta** — histórico com gráfico de saúde
- ✅ **Catálogo** — 12 plantas com busca e filtros
- ✅ **Calculadora de rega** — baseada no tipo de solo
- ✅ **Modo offline** — funciona sem internet (cache)
- ✅ **Comunidade** — compartilhe suas plantas
- ✅ **Loja** — compre plantas identificadas
