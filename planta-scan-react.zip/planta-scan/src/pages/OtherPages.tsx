import { useNavigate } from 'react-router-dom';
import { Plus, ArrowLeft, Bell, ShoppingBag, LogOut, Users } from 'lucide-react';
import { useState } from 'react';
import { useStore } from '../store';
import { catalogData } from '../data/catalog';
import HealthGauge from '../components/HealthGauge';
import PlantCard from '../components/PlantCard';
import BottomNav from '../components/BottomNav';
import { toast } from 'sonner';

// ─── Garden Page ───────────────────────────────────────────────────────────────
export function GardenPage() {
  const nav = useNavigate();
  const { plants, markWatered, setResult } = useStore();
  const needWater = plants.filter(p => p.needsWater);

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto scrollbar-none pb-4">
        <div className="flex items-center justify-between px-4 pt-6 pb-3 bg-white border-b border-cream-dark flex-shrink-0">
          <div>
            <h1 className="font-display text-2xl font-bold text-brown">Meu Jardim</h1>
            <p className="text-sm text-muted">{plants.length} plantas</p>
          </div>
          <button onClick={() => nav('/scan')} className="w-10 h-10 bg-green-light rounded-full flex items-center justify-center shadow-lg shadow-green-light/40">
            <Plus className="w-5 h-5 text-white" />
          </button>
        </div>

        <div className="px-4 mt-3 space-y-3">
          {/* Watering alerts */}
          {needWater.length > 0 && (
            <div className="bg-amber-50 border border-amber-200/60 rounded-2xl p-3.5">
              <div className="flex items-center gap-2 mb-2.5">
                <div className="w-7 h-7 bg-amber-100 rounded-full flex items-center justify-center">
                  <Bell className="w-3.5 h-3.5 text-warn" />
                </div>
                <span className="text-xs font-bold text-brown">Precisa de água hoje</span>
              </div>
              {needWater.map(p => (
                <div key={p.id} className="flex items-center justify-between py-2 border-t border-amber-100 first:border-t-0">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-lg overflow-hidden"><img src={p.foto} className="w-full h-full object-cover" alt={p.name} /></div>
                    <span className="font-display font-semibold text-sm text-brown">{p.name}</span>
                  </div>
                  <button onClick={() => { markWatered(p.id); toast.success('💧 Planta regada!'); }}
                    className="bg-green-light text-white rounded-xl px-3 py-1.5 text-xs font-bold">
                    Reguei ✓
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* Plant grid */}
          <div className="grid grid-cols-2 gap-3">
            {plants.map(p => (
              <div key={p.id} className="relative">
                <PlantCard {...p} needsWater={p.needsWater}
                  onClick={() => { setResult({ name: p.name, sci: p.sci, score: p.score, foto: p.foto }); nav('/result'); }} />
                <button onClick={() => nav(`/diary/${p.id}`)}
                  className="absolute bottom-14 right-2 bg-green-dark/80 text-white text-[9px] font-bold px-2 py-0.5 rounded-md">
                  📔 Diário
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
      <BottomNav />
    </div>
  );
}

// ─── Diary Page ────────────────────────────────────────────────────────────────
export function DiaryPage() {
  const nav = useNavigate();
  const { plants, addDiaryEntry } = useStore();
  const id = window.location.pathname.split('/').pop() || '';
  const plant = plants.find(p => p.id === id);

  if (!plant) return <div className="flex items-center justify-center h-full"><p className="text-muted">Planta não encontrada</p></div>;

  const entries = plant.diary;
  const first = entries[0]?.score || 0;
  const last  = entries[entries.length - 1]?.score || 0;
  const diff  = last - first;

  const handleAdd = () => {
    const note = window.prompt('Como está sua planta hoje?', 'Tudo bem!');
    if (!note) return;
    const today = new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
    addDiaryEntry(plant.id, { date: today, score: Math.min(100, last + Math.floor(Math.random() * 6) - 2), note, foto: plant.foto });
    toast.success('📔 Registro adicionado!');
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto scrollbar-none pb-4">
        <div className="flex items-center gap-3 px-4 pt-5 pb-3 flex-shrink-0">
          <button onClick={() => nav('/garden')} className="w-10 h-10 bg-white border border-cream-dark rounded-full flex items-center justify-center">
            <ArrowLeft className="w-5 h-5 text-brown" />
          </button>
          <div>
            <h1 className="font-display text-xl font-bold text-brown">📔 {plant.name}</h1>
            <p className="text-xs text-muted">Histórico de saúde</p>
          </div>
        </div>

        <div className="px-4 space-y-3">
          {/* Stats */}
          <div className="grid grid-cols-3 gap-2">
            <div className="bg-white rounded-2xl p-3 text-center border border-cream-dark">
              <p className="font-display text-xl font-bold text-green-light">{last}</p>
              <p className="text-[10px] text-muted">Saúde atual</p>
            </div>
            <div className="bg-white rounded-2xl p-3 text-center border border-cream-dark">
              <p className="font-display text-lg font-bold" style={{ color: diff >= 0 ? '#22c47f' : '#d63b3b' }}>
                {diff >= 0 ? '↑' : '↓'} {Math.abs(diff)}
              </p>
              <p className="text-[10px] text-muted">Evolução</p>
            </div>
            <div className="bg-white rounded-2xl p-3 text-center border border-cream-dark">
              <p className="font-display text-xl font-bold text-green-light">{entries.length}</p>
              <p className="text-[10px] text-muted">Registros</p>
            </div>
          </div>

          {/* Chart */}
          <div className="bg-white rounded-2xl p-4 border border-cream-dark">
            <p className="font-display font-semibold text-brown text-sm mb-3">Evolução da Saúde</p>
            <div className="flex items-end gap-2 h-14">
              {entries.map((e, i) => {
                const h = Math.round((e.score / 100) * 56);
                const c = e.score >= 75 ? '#22c47f' : e.score >= 50 ? '#e0780d' : '#d63b3b';
                return (
                  <div key={i} className="flex-1 flex flex-col items-center gap-1">
                    <span className="text-[9px] text-muted font-semibold">{e.score}</span>
                    <div className="w-full rounded-t-md" style={{ height: Math.max(h, 6), background: c }} />
                    <span className="text-[8px] text-muted">{e.date}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Timeline */}
          <div className="space-y-2">
            {[...entries].reverse().map((e, i) => (
              <div key={i} className="flex gap-3 items-start">
                <div className="w-11 h-11 rounded-xl overflow-hidden flex-shrink-0">
                  <img src={e.foto} className="w-full h-full object-cover" alt="" />
                </div>
                <div className="flex-1 bg-white rounded-2xl p-3 border border-cream-dark">
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-xs text-muted">{e.date}</span>
                    <span className="text-xs font-bold" style={{ color: e.score >= 75 ? '#22c47f' : '#e0780d' }}>{e.score}/100</span>
                  </div>
                  <p className="text-sm text-brown">{e.note}</p>
                </div>
              </div>
            ))}
          </div>

          <button onClick={handleAdd} className="w-full bg-green-light text-white rounded-2xl py-4 font-display font-bold shadow-xl shadow-green-light/35">
            + Adicionar Registro de Hoje
          </button>
        </div>
      </div>
      <BottomNav />
    </div>
  );
}

// ─── Catalog Page ──────────────────────────────────────────────────────────────
export function CatalogPage() {
  const nav = useNavigate();
  const [search, setSearch] = useState('');
  const [cat, setCat] = useState('todas');
  const cats = ['todas','interior','exterior','suculenta','florida','aromatica'];

  const filtered = catalogData.filter(p => {
    const matchCat = cat === 'todas' || p.categoria.includes(cat);
    const q = search.toLowerCase();
    const matchQ = !q || p.nomeLocal.toLowerCase().includes(q) || p.cientifico.toLowerCase().includes(q) || p.nomes.some(n => n.toLowerCase().includes(q));
    return matchCat && matchQ;
  });

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto scrollbar-none pb-4">
        <div className="px-4 pt-6 pb-2">
          <h1 className="font-display text-2xl font-bold text-brown">Catálogo</h1>
          <p className="text-sm text-muted mb-3">Conheça as plantas antes de escanear</p>
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Buscar planta ou nome regional..."
            className="w-full px-4 py-3 border border-cream-dark rounded-2xl text-sm bg-white outline-none text-brown mb-3" />
          <div className="flex gap-2 overflow-x-auto scrollbar-none pb-1">
            {cats.map(c => (
              <button key={c} onClick={() => setCat(c)}
                className={`flex-shrink-0 px-3.5 py-1.5 rounded-full text-xs font-semibold border transition-colors ${cat === c ? 'bg-green-light text-white border-transparent' : 'bg-white text-muted border-cream-dark'}`}>
                {c === 'todas' ? 'Todas' : c === 'interior' ? '🏠 Interior' : c === 'exterior' ? '🌳 Exterior' : c === 'suculenta' ? '🌵 Suculentas' : c === 'florida' ? '🌸 Floridas' : '🌿 Aromáticas'}
              </button>
            ))}
          </div>
        </div>

        {/* Scan banner */}
        <div className="mx-4 mb-3 rounded-2xl p-3.5 flex items-center justify-between" style={{ background: 'linear-gradient(135deg,#0a3322,#1a7a50)' }}>
          <div><p className="font-display font-bold text-white text-sm">Não sabe qual é?</p><p className="text-xs text-white/65">IA identifica pela foto</p></div>
          <button onClick={() => nav('/scan')} className="bg-green-light text-white rounded-xl px-4 py-2 text-xs font-bold">📷 Escanear</button>
        </div>

        <div className="px-4 grid grid-cols-2 gap-3">
          {filtered.map(p => (
            <button key={p.id} onClick={() => nav(`/catalog/${p.id}`)}
              className="bg-white rounded-2xl overflow-hidden border border-cream-dark shadow-sm text-left active:scale-97 transition-transform">
              <div className="relative h-32 overflow-hidden">
                <img src={p.foto} alt={p.nomeLocal} className="w-full h-full object-cover"
                  onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                <div className="absolute top-2 left-2 bg-white/90 rounded-lg px-2 py-0.5 text-[10px] font-bold"
                  style={{ color: p.dificuldade === 'Muito fácil' ? '#0a7a4d' : p.dificuldade === 'Fácil' ? '#1a9e6a' : p.dificuldade === 'Moderada' ? '#e07b1a' : '#d63b3b' }}>
                  {p.dificuldade}
                </div>
                {p.toxica && <div className="absolute top-2 right-2 bg-red-500/88 text-white text-[9px] font-bold px-1.5 py-0.5 rounded-lg">⚠ Tóxica</div>}
              </div>
              <div className="p-2.5">
                <p className="font-display font-bold text-sm text-brown">{p.nomeLocal}</p>
                <p className="text-[10px] text-muted italic">{p.cientifico}</p>
                <div className="flex gap-1.5 mt-1.5 flex-wrap">
                  <span className="text-[10px] bg-green-bg text-green-dark px-1.5 py-0.5 rounded-md">💧 {p.agua}</span>
                  <span className="text-[10px] bg-amber-50 text-amber-800 px-1.5 py-0.5 rounded-md">☀ {p.luz}</span>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
      <BottomNav />
    </div>
  );
}

// ─── Catalog Detail ────────────────────────────────────────────────────────────
export function CatalogDetailPage() {
  const nav = useNavigate();
  const id = window.location.pathname.split('/').pop() || '';
  const p = catalogData.find(x => x.id === id);
  if (!p) return <div className="flex items-center justify-center h-full"><p>Não encontrado</p></div>;

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto scrollbar-none pb-4">
        <div className="relative h-56 flex-shrink-0">
          <img src={p.foto} alt={p.nomeLocal} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-cream to-transparent" />
          <button onClick={() => nav('/catalog')} className="absolute top-4 left-4 w-10 h-10 bg-white/85 rounded-full flex items-center justify-center">
            <ArrowLeft className="w-5 h-5 text-brown" />
          </button>
          {p.toxica && <div className="absolute top-4 right-4 bg-red-500/90 text-white text-xs font-bold px-3 py-1.5 rounded-xl">⚠ Tóxica</div>}
        </div>
        <div className="px-4 -mt-10 relative z-10 space-y-3">
          <div className="bg-white rounded-2xl p-4 border border-cream-dark shadow-lg">
            <p className="text-[11px] font-bold text-green uppercase tracking-widest mb-1">{p.familia}</p>
            <h1 className="font-display text-2xl font-bold text-brown">{p.nomeLocal}</h1>
            <p className="text-xs text-muted italic mb-3">{p.cientifico}</p>
            <div className="flex flex-wrap gap-2">
              {p.categoria.map(c => <span key={c} className="text-xs bg-green-bg text-green-dark px-2.5 py-1 rounded-full font-medium">{c}</span>)}
              <span className="text-xs bg-gray-100 text-muted px-2.5 py-1 rounded-full">🌸 {p.florescimento}</span>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {[['💧', 'Rega', p.agua], ['☀️', 'Luz', p.luz], ['🌡️', 'Temp.', p.temp]].map(([icon, label, val]) => (
              <div key={label} className="bg-white rounded-2xl p-3 text-center border border-cream-dark">
                <span className="text-xl">{icon}</span>
                <p className="font-bold text-brown text-xs mt-1">{label}</p>
                <p className="text-[10px] text-muted mt-0.5">{val}</p>
              </div>
            ))}
          </div>
          <div className="rounded-2xl p-4 flex gap-3" style={{ background: 'linear-gradient(135deg,#0d3b22,#1a7a50)' }}>
            <span className="text-2xl">💡</span>
            <div><p className="font-display font-bold text-white text-sm mb-1">Curiosidade</p><p className="text-xs text-white/75 leading-relaxed">{p.curiosidade}</p></div>
          </div>
          <div className="bg-white rounded-2xl p-4 border border-cream-dark">
            <div className="flex items-center gap-2 mb-3"><span className="text-lg">🌍</span><p className="font-display font-bold text-brown text-sm">Nomes ao redor do mundo</p></div>
            {p.nomes.map((n, i) => (
              <div key={i} className="flex items-center gap-2 py-2 border-t border-cream-dark first:border-t-0">
                <div className="w-1.5 h-1.5 rounded-full bg-green-light flex-shrink-0" />
                <span className="text-sm text-brown">{n}</span>
              </div>
            ))}
          </div>
          <button onClick={() => nav('/scan')} className="w-full bg-green-light text-white rounded-2xl py-4 font-display font-bold shadow-xl shadow-green-light/35 flex items-center justify-center gap-2">
            📷 Escanear esta planta
          </button>
        </div>
      </div>
      <BottomNav />
    </div>
  );
}

// ─── Profile Page ──────────────────────────────────────────────────────────────
export function ProfilePage() {
  const nav = useNavigate();
  const { plants, scanCount, isOffline, setOffline } = useStore();
  const [notif, setNotif] = useState(true);

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto scrollbar-none pb-4">
        <div className="relative overflow-hidden flex-shrink-0 px-5 pt-8 pb-20"
          style={{ background: 'linear-gradient(135deg,#0d3b22,#1a7a50)' }}>
          <div className="absolute top-0 right-0 w-40 h-40 rounded-full bg-white/4 -translate-y-1/2 translate-x-1/2" />
          <div className="flex items-center gap-4 relative z-10">
            <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center border-2 border-white/30">
              <span className="font-display font-bold text-white text-3xl">J</span>
            </div>
            <div>
              <h2 className="font-display font-bold text-white text-xl">Jardineiro</h2>
              <p className="text-white/65 text-xs mt-0.5">usuario@email.com</p>
              <span className="bg-white/15 text-white text-xs font-semibold px-2.5 py-1 rounded-full mt-2 inline-block">🌿 Nível 2 — Jardineiro</span>
            </div>
          </div>
        </div>

        <div className="px-4 -mt-10 relative z-10 space-y-3">
          <div className="bg-white rounded-2xl overflow-hidden border border-cream-dark shadow-lg">
            <div className="grid grid-cols-3 divide-x divide-cream-dark">
              {[['Plantas', plants.length], ['Scans', scanCount], ['Saúde', '78%']].map(([l, v]) => (
                <div key={l} className="py-4 text-center">
                  <p className="font-display text-2xl font-bold text-green-light">{v}</p>
                  <p className="text-[10px] text-muted mt-0.5">{l}</p>
                </div>
              ))}
            </div>
          </div>

          {/* XP bar */}
          <div className="bg-white rounded-2xl p-4 border border-cream-dark">
            <div className="flex justify-between text-xs mb-2"><span className="font-semibold text-brown">Progresso Nível 3</span><span className="text-muted">340 / 500 XP</span></div>
            <div className="h-2 bg-cream-dark rounded-full overflow-hidden">
              <div className="h-full w-[68%] rounded-full" style={{ background: 'linear-gradient(to right,#1a9e6a,#22c47f)' }} />
            </div>
          </div>

          {/* Menu items */}
          {[
            { icon: Users, label: 'Comunidade', sub: 'Ver plantas de outros usuários', action: () => toast.info('Comunidade em breve!') },
            { icon: ShoppingBag, label: 'Loja Parceira', sub: 'Compre plantas identificadas', action: () => toast.info('Loja em breve!') },
            { icon: Bell, label: 'Notificações', sub: 'Alertas de rega e saúde', toggle: notif, onToggle: () => { setNotif(!notif); toast.success(!notif ? '🔔 Notificações ativadas' : '🔕 Desativadas'); } },
          ].map(item => (
            <button key={item.label} onClick={item.action || item.onToggle}
              className="w-full bg-white rounded-2xl p-4 flex items-center gap-3 border border-cream-dark shadow-sm">
              <div className="w-10 h-10 bg-green-bg rounded-xl flex items-center justify-center flex-shrink-0">
                <item.icon className="w-5 h-5 text-green" />
              </div>
              <div className="flex-1 text-left">
                <p className="font-display font-semibold text-brown text-sm">{item.label}</p>
                <p className="text-xs text-muted">{item.sub}</p>
              </div>
              {item.toggle !== undefined ? (
                <div className="w-11 h-6 rounded-full relative transition-colors" style={{ background: item.toggle ? '#22c47f' : '#ddd' }}>
                  <div className="w-5 h-5 bg-white rounded-full absolute top-0.5 transition-transform shadow-sm" style={{ transform: item.toggle ? 'translateX(20px)' : 'translateX(2px)' }} />
                </div>
              ) : <ArrowLeft className="w-4 h-4 text-muted rotate-180" />}
            </button>
          ))}

          {/* Offline toggle */}
          <button onClick={() => { setOffline(!isOffline); toast.success(!isOffline ? '📵 Modo offline ativado' : '🌐 Online restaurado'); }}
            className="w-full bg-white rounded-2xl p-4 flex items-center gap-3 border border-amber-200/60 shadow-sm">
            <div className="w-10 h-10 bg-amber-50 rounded-xl flex items-center justify-center flex-shrink-0">
              <span className="text-lg">📵</span>
            </div>
            <div className="flex-1 text-left">
              <p className="font-display font-semibold text-brown text-sm">Modo Offline</p>
              <p className="text-xs text-muted">Funciona sem internet</p>
            </div>
            <div className="w-11 h-6 rounded-full relative transition-colors" style={{ background: isOffline ? '#e0780d' : '#ddd' }}>
              <div className="w-5 h-5 bg-white rounded-full absolute top-0.5 transition-transform shadow-sm" style={{ transform: isOffline ? 'translateX(20px)' : 'translateX(2px)' }} />
            </div>
          </button>

          <button onClick={() => nav('/login')}
            className="w-full bg-white rounded-2xl p-4 flex items-center gap-3 border border-red-200 shadow-sm">
            <div className="w-10 h-10 bg-red-50 rounded-xl flex items-center justify-center flex-shrink-0">
              <LogOut className="w-5 h-5 text-red-500" />
            </div>
            <span className="font-display font-semibold text-red-500 text-sm">Sair da conta</span>
          </button>
        </div>
      </div>
      <BottomNav />
    </div>
  );
}
