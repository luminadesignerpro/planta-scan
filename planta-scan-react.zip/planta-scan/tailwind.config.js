/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        green: {
          light: '#22c47f',
          DEFAULT: '#1a9e6a',
          dark: '#0d6b47',
          bg: '#eaf7f1',
        },
        cream: {
          DEFAULT: '#f8f5ef',
          dark: '#ede9e0',
        },
        brown: '#1c1510',
        warn: '#e0780d',
      },
      fontFamily: {
        display: ['Fraunces', 'serif'],
        body: ['DM Sans', 'sans-serif'],
      },
      borderRadius: {
        xl: '20px',
        '2xl': '24px',
      }
    }
  },
  plugins: []
};
